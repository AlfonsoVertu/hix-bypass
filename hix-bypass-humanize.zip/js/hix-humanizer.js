jQuery(document).ready(function($) {
    $('#hix-humanize-btn').on('click', function() {
        var content = $('article').html().replace(/<h[1-6].*?>.*?<\/h[1-6]>/g, '');
        var endpoint = $('#hix-endpoint').val();
        var apiKey = $('#hix-api-key').val();
        var mode = $('#hix-mode').val();
        var language = $('#hix-language').val();

        $.ajax({
            type: 'POST',
            url: hixHumanizer.ajax_url,
            data: {
                action: 'hix_humanize_text',
                nonce: hixHumanizer.nonce,
                endpoint: endpoint,
                api_key: apiKey,
                text: content,
                mode: mode,
                language: language
            },
            success: function(response) {
                if (response.success) {
                    $('article').html(response.data);
                } else {
                    alert('Error humanizing text');
                }
            }
        });
    });
});
