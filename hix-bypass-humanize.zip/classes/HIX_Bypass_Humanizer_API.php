<?php

class HIX_Bypass_Humanizer_API {
    private $api_url;
    private $api_key;

    public function __construct($api_url, $api_key) {
        $this->api_url = $api_url;
        $this->api_key = $api_key;
    }

    public function humanize_text($text, $mode = 'balanced', $language = 'en') {
        $response = wp_remote_post($this->api_url, [
            'body'    => json_encode(['text' => $text, 'mode' => $mode, 'language' => $language]),
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key,
            ],
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);

        return $result['humanized_text'] ?? false;
    }
}
