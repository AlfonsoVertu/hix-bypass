<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class HIX_Bypass_Humanizer_Metabox {

    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_custom_metabox'));
        add_action('save_post', array($this, 'save_custom_metabox_data'));
    }

    public function add_custom_metabox() {
        add_meta_box(
            'hix_text_humanizer_metabox',
            'HIX Text Humanizer',
            array($this, 'custom_metabox_callback'),
            ['post', 'page'],
            'side',
            'high'
        );
    }

    public function custom_metabox_callback($post) {
        // Recupera i valori salvati
        $api_key = get_post_meta($post->ID, '_hix_api_key', true);
        $endpoint = get_post_meta($post->ID, '_hix_endpoint', true);
        $mode = get_post_meta($post->ID, '_hix_mode', true);
        $word_limit = get_post_meta($post->ID, '_hix_word_limit', true);

        // Form per input dei parametri API
        echo '<p><label for="hix_api_key">API Key:</label>';
        echo '<input type="text" id="hix_api_key" name="hix_api_key" value="' . esc_attr($api_key) . '" class="widefat" placeholder="Inserisci API Key"></p>';

        echo '<p><label for="hix_endpoint">Endpoint:</label>';
        echo '<input type="text" id="hix_endpoint" name="hix_endpoint" value="' . esc_attr($endpoint) . '" class="widefat" placeholder="Inserisci Endpoint API"></p>';

        echo '<p><label for="hix_mode">Modalità:</label>';
        echo '<select id="hix_mode" name="hix_mode" class="widefat">';
        echo '<option value="fast"' . selected($mode, 'fast', false) . '>Fast</option>';
        echo '<option value="balanced"' . selected($mode, 'balanced', false) . '>Balanced</option>';
        echo '<option value="aggressive"' . selected($mode, 'aggressive', false) . '>Aggressive</option>';
        echo '</select></p>';

        echo '<p><label for="hix_word_limit">Limite Parole per Richiesta:</label>';
        echo '<input type="number" id="hix_word_limit" name="hix_word_limit" value="' . esc_attr($word_limit) . '" class="widefat" placeholder="Es. 2000"></p>';
    }

    public function save_custom_metabox_data($post_id) {
        if (isset($_POST['hix_api_key'])) {
            update_post_meta($post_id, '_hix_api_key', sanitize_text_field($_POST['hix_api_key']));
        }
        if (isset($_POST['hix_endpoint'])) {
            update_post_meta($post_id, '_hix_endpoint', sanitize_text_field($_POST['hix_endpoint']));
        }
        if (isset($_POST['hix_mode'])) {
            update_post_meta($post_id, '_hix_mode', sanitize_text_field($_POST['hix_mode']));
        }
        if (isset($_POST['hix_word_limit'])) {
            update_post_meta($post_id, '_hix_word_limit', intval($_POST['hix_word_limit']));
        }
    }
}

new HIX_Bypass_Humanizer_Metabox();
