<?php

class HIX_Bypass_Humanizer_Installer {
    public static function activate() {
        add_option('hix_humanizer_api_key', '');
    }

    public static function deactivate() {
        delete_option('hix_humanizer_api_key');
    }
}
