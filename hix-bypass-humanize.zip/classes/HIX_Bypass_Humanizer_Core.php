<?php

class HIX_Bypass_Humanizer_Core {
    public static function init() {
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_scripts']);
    }

    public static function enqueue_scripts() {
        wp_enqueue_script('hix-humanizer-js', plugin_dir_url(__FILE__) . '../js/hix-humanizer.js', ['jquery'], '1.0', true);
        wp_localize_script('hix-humanizer-js', 'hixHumanizer', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('hix_humanizer_nonce')
        ]);
    }
}
