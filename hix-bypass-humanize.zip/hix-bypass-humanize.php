<?php
/**
 * Plugin Name: Working with AI Humanize
 * Description: A plugin to humanize article text using HIX.AI API.
 * Version: 1.0
 * Author: Alfonso Vertucci
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'classes/HIX_Bypass_Humanizer_API.php';
require_once plugin_dir_path(__FILE__) . 'classes/HIX_Bypass_Humanizer_Widget.php';
require_once plugin_dir_path(__FILE__) . 'classes/HIX_Bypass_Humanizer_Installer.php';
require_once plugin_dir_path(__FILE__) . 'classes/HIX_Bypass_Humanizer_Core.php';

register_activation_hook(__FILE__, ['HIX_Bypass_Humanizer_Installer', 'activate']);
register_deactivation_hook(__FILE__, ['HIX_Bypass_Humanizer_Installer', 'deactivate']);

add_action('plugins_loaded', ['HIX_Bypass_Humanizer_Core', 'init']);
